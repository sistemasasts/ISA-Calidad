package com.isacore.sgc.acta.service;

import com.isacore.sgc.acta.model.MeetingMinute;
import com.isacore.util.CRUD;

public interface IMeetingMinuteService extends CRUD<MeetingMinute>{

}
