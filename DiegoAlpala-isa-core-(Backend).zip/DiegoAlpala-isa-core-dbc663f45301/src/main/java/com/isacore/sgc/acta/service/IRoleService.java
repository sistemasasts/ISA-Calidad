package com.isacore.sgc.acta.service;

import com.isacore.sgc.acta.model.Role;
import com.isacore.util.CRUD;

public interface IRoleService extends CRUD<Role>{

}
