package com.isacore.sgc.acta.service;

import com.isacore.sgc.acta.model.Committee;
import com.isacore.util.CRUD;

public interface ICommitteeService extends CRUD<Committee>{

}
