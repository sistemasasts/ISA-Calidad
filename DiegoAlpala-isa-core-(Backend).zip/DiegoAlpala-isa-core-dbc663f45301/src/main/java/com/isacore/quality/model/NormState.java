package com.isacore.quality.model;

public enum NormState {

	VIGENTE,
	ANULADA
}
