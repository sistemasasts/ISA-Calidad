package com.isacore.quality.service;

import com.isacore.quality.model.ProviderActionPlan;
import com.isacore.util.CRUD;

public interface IProviderActionPlanService extends CRUD<ProviderActionPlan> {

}
