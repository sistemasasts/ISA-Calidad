package com.isacore.quality.service;

import com.isacore.quality.model.Area;
import com.isacore.util.CRUD;

public interface IAreasService extends CRUD<Area>{

}
