package com.isacore.quality.model.se;

public enum TipoAprobacionSolicitud {

	LABORATORIO,
	PLANTA,
	LIBRE_USO,
	NO_APROBADO
}
