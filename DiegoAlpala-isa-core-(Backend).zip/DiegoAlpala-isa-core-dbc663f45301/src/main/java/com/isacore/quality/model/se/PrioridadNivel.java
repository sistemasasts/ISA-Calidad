package com.isacore.quality.model.se;

public enum PrioridadNivel {
	ALTO,
	MEDIO,
	BAJO;
}
