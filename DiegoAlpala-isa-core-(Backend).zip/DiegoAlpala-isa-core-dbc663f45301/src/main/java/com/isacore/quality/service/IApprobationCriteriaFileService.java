package com.isacore.quality.service;

public interface IApprobationCriteriaFileService {	
	
	void deleteById(long criteriaFileId);

}
