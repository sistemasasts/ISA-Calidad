package com.isacore.quality.model.se;

public enum TipoSolicitud {

	SOLICITUD_ENSAYOS,
	SOLICITUD_PRUEBAS_EN_PROCESO,
	
}
