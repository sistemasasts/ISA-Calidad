package com.isacore.quality.service;

import com.isacore.quality.model.ClientImptek;
import com.isacore.util.CRUD;

public interface IClientImptekService extends CRUD<ClientImptek>{

}
