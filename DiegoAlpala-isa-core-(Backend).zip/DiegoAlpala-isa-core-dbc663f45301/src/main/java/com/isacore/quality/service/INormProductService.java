package com.isacore.quality.service;

import com.isacore.quality.model.NormProduct;
import com.isacore.quality.model.Property;
import com.isacore.util.CRUD;

public interface INormProductService extends CRUD<NormProduct> {

}
