package com.isacore.quality.exception;

@SuppressWarnings("serial")
public class FileReadErrorException extends QualityException {

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "Error al leer el archivo";
	}
	

}
