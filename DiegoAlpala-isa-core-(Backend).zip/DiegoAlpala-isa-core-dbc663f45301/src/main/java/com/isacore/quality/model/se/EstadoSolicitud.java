package com.isacore.quality.model.se;

public enum EstadoSolicitud {

	NUEVO,
	ENVIADO_REVISION,
	EN_PROCESO,
	REVISION_INFORME,
	FINALIZADO,
	RECHAZADO,
	REGRESADO_NOVEDAD_INFORME,
	ANULADO;
}
