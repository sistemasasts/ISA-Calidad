package com.isacore.quality.service;

import com.isacore.quality.model.ExecutedAction;
import com.isacore.util.CRUD;

public interface IExecutedActionService extends CRUD<ExecutedAction> {

}
