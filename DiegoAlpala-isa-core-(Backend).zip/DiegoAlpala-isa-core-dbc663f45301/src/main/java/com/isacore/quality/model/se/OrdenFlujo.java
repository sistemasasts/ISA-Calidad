package com.isacore.quality.model.se;

public enum OrdenFlujo {

	INGRESO_SOLICITUD,
	VALIDAR_SOLICITUD,
	RESPONDER_SOLICITUD,
	APROBAR_INFORME	
}
