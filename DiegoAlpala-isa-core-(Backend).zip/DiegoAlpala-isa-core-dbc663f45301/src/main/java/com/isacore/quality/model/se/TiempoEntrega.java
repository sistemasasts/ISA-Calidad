package com.isacore.quality.model.se;

public enum TiempoEntrega {
	INMEDIATO,
	MEDIO,
	BAJO,
	CASOS_ESPECIALES;
}
