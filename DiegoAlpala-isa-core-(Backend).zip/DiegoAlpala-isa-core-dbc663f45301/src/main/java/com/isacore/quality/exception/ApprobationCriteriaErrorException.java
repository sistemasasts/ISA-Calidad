package com.isacore.quality.exception;

@SuppressWarnings("serial")
public class ApprobationCriteriaErrorException extends QualityException {

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "Error en subir el archivo";
	}
	

}
