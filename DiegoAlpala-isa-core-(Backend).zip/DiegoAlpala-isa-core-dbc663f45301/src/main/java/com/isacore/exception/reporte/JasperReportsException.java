package com.isacore.exception.reporte;

@SuppressWarnings("serial")
public class JasperReportsException extends Exception {

}
